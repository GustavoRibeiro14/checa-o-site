const {verificarSenhas,checar} = require('./Form')

it('Testando se a senha com menos de 8 digitos é valida', () => {
    expect(verificarSenhas("Abc123@")).toBe(false)
})

it('Testando se a senha com mais de 8 digitos é valida', () => {
    expect(verificarSenhas("Abcd1234@")).toBe(true)
})

it('Testando se a senha valida é valida', () => {
    expect(verificarSenhas("Abcde1234@")).toBe(true)
}) 

it('Testando se a senha é válida sem maiscula', () => {
    expect(verificarSenhas("abcde1234@")).toBe(false)
})

it('Testando se a senha é válida apenas com maiscula', () => {
    expect(verificarSenhas("ABCD234@")).toBe(false)
})

it('Testando se a senha é valida com maiscula e minuscula', () => {
    expect(verificarSenhas("Abcde1234@")).toBe(true)
})

it('Testando se a senha é valida sem letras', () => {
    expect(verificarSenhas("12341234@")).toBe(false)
})

it('Testando se a senha é valida apenas letras', () => {
    expect(verificarSenhas("Abcdefghi@")).toBe(false)
})

it('Testando se a senha é valida com letras e numeros', () => {
    expect(verificarSenhas("Abcde1234@")).toBe(true)
})

it('Testando se a senha é valida sem numeros', () => {
    expect(verificarSenhas("Abcdefghi@")).toBe(false)
})

it('Testando se a senha é valida com apenas numeros', () => {
    expect(verificarSenhas("12345678")).toBe(false)
})

it('Testando se a senha é valida com numeros e letras', () => {
    expect(verificarSenhas("Abcd1234@")).toBe(true)
})

it('Testando se a senha é valida sem caracter especial', () => {
    expect(verificarSenhas("Abcde1234")).toBe(false)
})

it('Testando se a senha é valida com caracter especial', () => {
    expect(verificarSenhas("Abcde1234@")).toBe(true)
})

it('Testando se as senhas não se coincidem', () => {
    expect(checar("Abcd2342@","Abcd2342")).toBe(false)
})

it('Testando se as senhas se coincidem', () => {
    expect(checar("Abcde1234@","Abcde1234@")).toBe(true)
})
